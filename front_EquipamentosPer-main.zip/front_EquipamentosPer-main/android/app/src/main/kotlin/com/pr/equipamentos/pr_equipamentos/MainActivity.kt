package com.pr.equipamentos.pr_equipamentos

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
